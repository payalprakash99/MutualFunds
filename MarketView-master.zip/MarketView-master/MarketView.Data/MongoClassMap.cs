﻿using MarketView.Models;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.IdGenerators;
using MongoDB.Bson.Serialization.Serializers;
using System;
using System.Collections.Generic;
using System.Text;

namespace MarketView.Data
{
    public class MongoClassMap
    {
        public static void Map()
        {

        }
    }
}
