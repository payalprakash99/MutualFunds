﻿using MarketView.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MarketView.Data
{
    public interface IMutualFundLibrary
    {
        List<MutualFund> GetMutualFundInfo();
    }
}
