﻿using MarketView.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace MarketView.Data
{
    public class MutualFundLibary : IMutualFundLibrary
    {

        //MongoConfigurations Configurations { get; }
        public IMongoHandler MongoHandler { get; set; }

        public IMongoCollection<MutualFund> _mutualFundCollection;

        public IMongoCollection<MutualFund> MutualFundCollection
        {

            get
            {
                if (_mutualFundCollection == null)
                {
                    var collectionName = MongoConfigurations.GetCollectionName<MutualFund>();

                    _mutualFundCollection = MongoHandler.Db.GetCollection<MutualFund>(collectionName);
                    
                    System.Diagnostics.Debug.WriteLine(_mutualFundCollection);

                }

                return _mutualFundCollection;
            }
        }

        public MutualFundLibary(IMongoHandler dataHandler)
        {
            this.MongoHandler = dataHandler;
        }

        public List<MutualFund> GetMutualFundInfo()
        {
            //List<MutualFund> result = new List<MutualFund>();

            //Query
            //result = MutualFundCollection.Find(new BsonDocument()).ToList();

            var query = MutualFundCollection.AsQueryable<MutualFund>()
                .Where(e => e.MetaData.FundHouse == "Aditya Birla Sun Life Mutual Fund")
                .Select(e => e);

            var list = query.ToList();

            return list;
        }


    }
}
