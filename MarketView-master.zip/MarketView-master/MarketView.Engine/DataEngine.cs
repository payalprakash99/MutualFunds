﻿using MarketView.Models;
using System;
using System.Collections.Generic;

namespace MarketView.Engine
{
    public class DataEngine : IDataEngine
    {
        public Data.IMutualFundLibrary MutualFundLibrary { get; set; }

        public DataEngine(Data.IMutualFundLibrary mutualFundLibrary)
        {
            this.MutualFundLibrary = mutualFundLibrary;
        }

        public List<MutualFund> GetMutualFundInfo()
        {
            System.Diagnostics.Debug.WriteLine("Inside DataEngine");

            List<MutualFund> resultList = this.MutualFundLibrary.GetMutualFundInfo();

            System.Diagnostics.Debug.WriteLine("Outside DataEngine");

            return resultList;
        }
    }
}
