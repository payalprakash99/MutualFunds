﻿using MarketView.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MarketView.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalculationService : ControllerBase
    {
        //[HttpGet]
        //public List<MutualFund> Get()
        //{
        //    var rng = new Random();
        //    return new List<MutualFund>();
        //}
    }
}
