﻿using MarketView.Commons;
using MarketView.Engine;
using MarketView.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MarketView.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataService : ControllerBase
    {
        public IDataEngine Engine { get; }

        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(DataService));

        public DataService(IDataEngine engine)
        {
            this.Engine = engine;
        }


        //[Route("api/dataservice/")]
        [HttpGet]
        public List<MutualFund> GetMutualFundInfo()
        {
            List<MutualFund> result;

            System.Diagnostics.Debug.WriteLine("Inside Data Service");

            result = this.Engine.GetMutualFundInfo();

            Logging.LogInfo(this.GetType().Name, "From DataService Started");

            System.Diagnostics.Debug.WriteLine("Outside Data Service");

            return result;
        }

    }
}
