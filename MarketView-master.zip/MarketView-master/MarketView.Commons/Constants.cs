﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketView.Commons
{
    public class Constants
    {
        public const int MongoDBDefaultPort = 27017;
    }
}
